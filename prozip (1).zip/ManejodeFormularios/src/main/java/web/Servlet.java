/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package web;

/**
 *
 * @author ADMIN-ITQ-009
 * 
 * anotacion sirve para enlazarme desde el servlet llave
 */



import javax.servlet.http.HttpServlet;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Servlet")

public class Servlet extends HttpServlet {
    
}
